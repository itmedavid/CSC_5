/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/*
 * File:   main.cpp
 * Author: David
 *
 * Created on February 18, 2025, 6:36 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char **argv)
{

  // Init variables
  int a;
  int b;
  int c;

  // Define Variables
  a = 10;
  b = 20;
  c = 30;

  // product calculation
  int product = a * b * c;

  // Display product
  cout << product << endl;

  return 0;
}
