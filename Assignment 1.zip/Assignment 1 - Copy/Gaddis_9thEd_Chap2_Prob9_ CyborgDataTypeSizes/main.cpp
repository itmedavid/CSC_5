/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/*
 * File:   main.cpp
 * Author: David
 *
 * Created on February 22, 2025, 2:57 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 *
 */
int main(int argc, char **argv)
{

    // Display the information
    cout << "Size of char " << sizeof(char) << " bytes" << endl;
    cout << "Size of int " << sizeof(int) << " bytes" << endl;
    cout << "Size of float " << sizeof(float) << " bytes" << endl;
    cout << "Size of double " << sizeof(double) << " bytes" << endl;
    return 0;
}
